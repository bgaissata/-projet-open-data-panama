from py2neo import Graph, Node, Relationship
import pandas as pd

# Connexion à Neo4j
# Connexion à Neo4j
# Connexion à Neo4j avec le mot de passe correct
graph = Graph("bolt://localhost:7687", auth=("neo4j", "Miage2025!"))




# Chargement des fichiers CSV
edges = pd.read_csv("../data/014fe3bc-edges.csv")  # Adapte ici selon ton fichier
nodes = pd.read_csv("../data/014fe3bc-nodes.csv")  # Idem

# Suppression des anciennes données dans Neo4j
graph.run("MATCH (n) DETACH DELETE n")

# Dictionnaire pour stocker les nœuds créés
node_dict = {}

# Création des nœuds (Personnes & Entreprises)
for _, row in nodes.iterrows():
    # Utilisation de MERGE pour éviter les doublons de nœuds
    node = Node("Entity", name=row["name"], country=row["country"])
    graph.merge(node, "Entity", "name")  # Assure que chaque entité est unique par son "name"
    node_dict[row["name"]] = node

# Création des relations
for _, row in edges.iterrows():
    start_node = node_dict.get(row["start_node"])  # Adapté selon les colonnes du fichier
    end_node = node_dict.get(row["end_node"])     # Adapté selon les colonnes du fichier
    if start_node and end_node:
        # Création de la relation entre les nœuds
        graph.create(Relationship(start_node, "CONNECTED_TO", end_node))

print("🚀 Importation terminée !")
